<template>
  <div>
    <h2>게시글 수정</h2>
    <hr class="my-4" />
    <PostForm
      v-model:title="form.title"
      v-model:content="form.content"
      @submit.prevent="editPost"
    >
      <template #actions>
        <button
          type="button"
          class="btn btn-outline-danger me-2"
          @click="goDetailPage"
        >
          취소
        </button>
        <button class="btn btn-primary" @click="editPost">수정</button>
      </template>
    </PostForm>
  </div>
</template>

<script setup>
import { useRouter } from "vue-router";
import { ref } from "vue";
import { getPostById, updatePost } from "@/api/posts";
import PostForm from "@/components/posts/PostForm.vue";

const router = useRouter();
const props = defineProps({
  id: String,
});

const id = props.id;

const editPost = async () => {
  try {
    await updatePost(props.id, { ...form.value });
    router.push({ name: "PostDetail", params: { id } });
  } catch (error) {}
};

const form = ref({
  title: null,
  content: null,
});

const fetchPost = async () => {
  try {
    const { data } = await getPostById(props.id);
    setForm(data);
  } catch (error) {
    console.error(error);
  }
};

const setForm = ({ title, content }) => {
  form.value.title = title;
  form.value.content = content;
};

fetchPost();

const goDetailPage = () => {
  router.push({
    name: "PostDetail",
    params: { id: props.id },
  });
};

const goList = () => {
  router.push({
    name: "PostList",
  });
};
</script>

<style lang="scss" scoped></style>
