<template>
  <div>
    <h2>게시글 등록</h2>
    <hr class="my-4" />
    <PostForm
      v-model:title="form.title"
      v-model:content="form.content"
      @submit.prevent="save"
    >
      <template #actions>
        <button
          type="button"
          class="btn btn-outline-danger me-2"
          @click="goList"
        >
          목록
        </button>
        <button class="btn btn-primary" @click="save">저장</button>
      </template>
    </PostForm>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { createPost } from "@/api/posts";
import PostForm from "@/components/posts/PostForm.vue";

const router = useRouter();

const form = ref({
  title: null,
  content: null,
});

const save = () => {
  try {
    createPost({
      ...form.value,
      createAt: Date.now(),
    });

    router.push({ name: "PostList" });
  } catch (error) {
    console.error(error);
  }
};

const goList = () => {
  router.push({
    name: "PostList",
  });
};
</script>

<style lang="scss" scoped></style>
