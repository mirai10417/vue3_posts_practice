<template>
	<main>
		<div class="container py-4">
			<RouterView></RouterView>
		</div>
	</main>
</template>

<script setup></script>

<style lang="scss" scoped></style>
